// ====> Problem Solving (Task '7' in 12)<====


// Task: 1
// Title: Basic Object and Method
// Objective: Create a simple object with methods to represent a person.
// Task:
// Create an object person with properties like name, age, and gender.
// Implement a method introduce() that logs a message introducing the person.
// Call the introduce() method to demonstrate the functionality.

// Solution: 

// let person = {
//     name: 'MD Din Islam',
//     age: 22,
//     gender: 'male'
// }
// console.log(person);



// ***Task: 2:--
// Title: Class and Instantiation
// Objective: Understand the basics of classes and instantiation.
// Task:
// Define a class Book with properties like title, author, and publishedYear.
// Instantiate two instances of the Book class with different values.
// Access and log the properties of each instance.

// Solution:

// class Book {
//     constructor( title, author, publishedYear) {
//         this.title = title;
//         this.author = author;
//         this.publishedYear = publishedYear;
//     }
// }
// let myBook = new Book('JavaScript: The Good Parts', 'Douglas Crockford', 2008)
// console.log(myBook);



// ***Task: 3:--
// Title: Using new Keyword
// Objective: Practice creating objects using the new keyword.
// Task:
// Define a class Dog with properties like name and breed.
// Create an instance of Dog using the new keyword.
// Set the properties of the dog and log them.

// Solution: 

// class Dog {
//     constructor(name, breed) {
//         this.name = name;
//         this.breed = breed;
//     }
// }
// let myDog = new Dog('Bulldog', 'Poodle')
// console.log(myDog);



// ***Task: 5:--
// Title: Understanding Polymorphism
// Objective: Explore polymorphism with a common interface.
// Task:
// Define a class Shape with a method draw() that logs a message.
// Create subclasses Circle and Square that extend Shape.
// Implement the draw() method in each subclass to display shape-specific messages.
// Create instances of both Circle and Square and call their draw() methods.

// Solution:
class Shape {
    constructor() {
        console.log(Shape);
    }
}









// ***Task: 9:--
// Title: JavaScript Inheritance with Animals
// Objective:
// Explore inheritance by creating a hierarchy of animal classes.
// Task:
// Define a base class Animal with properties like name and sound.
// Create subclasses Dog and Cat that extend Animal.
// Implement the makeSound() method for each subclass.
// Create instances of both Dog and Cat and call their makeSound() methods.

// Solution:

class Animal {
    constructor(name, sound) {
        this.name = name,
        this.sound = sound
    }
    makeSound() {
        console.log(`${this.name} sound like ${this.sound}`);
      }
}
class Dog extends Animal {
    constructor(name, sound) {
        super (name,  sound,)
    }
}
class Cat extends Animal{
    constructor(name, sound) {
        super(name, sound)
    }
}
const dog = new Dog('mona', 'Wooof!');
const cat = new Cat('simba', 'Meow!')

cat.makeSound();
dog.makeSound()
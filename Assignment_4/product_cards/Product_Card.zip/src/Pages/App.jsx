import Products from '../Components/Products/Products'
import './App.css'
import React, { useState } from 'react'
export default function App() {
  
  return (
    <>
    <div>
      <h1 className='heading'>Task 1: Create a Product Card Component</h1>
      <Products/>
    </div>
    </>
  )
}

